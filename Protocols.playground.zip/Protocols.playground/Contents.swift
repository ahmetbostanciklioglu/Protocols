import UIKit

//MARK: Protocols as a parameter type
protocol ProtocolName {
    var property: String { get set}
}
func protocolFunction(param: ProtocolName) {
    print("\(param.property)")
}


//Struct With Property
struct StructWithProperty {
    var property: String
}
func structOfFunction(_ param: StructWithProperty) {
    print("\(param.property)")
}


//MARK: Using property of protocol in structs
protocol ProtocolProperty {
    var propertyOfProtocol: String { get set }
}

struct Struct : ProtocolProperty {
    var propertyOfProtocol: String
    var propertyOfStruct  : String
}

struct Struct2 : ProtocolProperty {
    var propertyOfProtocol: String
    var propertyOfStruct  : String
    
    func structFunction(_ param: ProtocolProperty) {
        print("\(param.propertyOfProtocol)")
    }
}


//MARK: Protocol Inheritance:
protocol Vehicle {
    var wheel:     Int { get set }
    var door :     Int { get set }
    var window:    Int { get set }
    var capacity:  Int { get set }
}

protocol TestModel: Vehicle {
    var logo: String { get set}
}


//MARK: Protocol Method
protocol ProtocolMethod {
    func method()
}

protocol ProtocolMethod2 {
    func method2()
}

protocol InheritedProtocol : ProtocolMethod, ProtocolMethod2 {
}



